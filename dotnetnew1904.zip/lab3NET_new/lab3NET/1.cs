﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace lab3NET
{
    class _1
    {
        static void Main(string[] args)
        {

            string ch = "qwertyuiopasdfghjklzxcvbnm";
            char[] alph = ch.ToCharArray();
            Random rnd = new Random();
            int t = rnd.Next(10, 20);
            Console.WriteLine("Количество строк: "+t);
            Console.WriteLine();
            
            string[] arrSymb = new string[t];
            string[][] myArr = new string[t][];
            for(int i = 0; i < t; i++)
            {
                myArr[i] = new string[1];
            }
            for (int i = 0; i < t; i++)
            {
                int k = rnd.Next(1, 10);
                
                for (int m = 0; m < k; m++)
                {
                    arrSymb[m] = alph[rnd.Next(alph.Length)].ToString();
                    myArr[i][0] = myArr[i][0] + arrSymb[m];
                }
            }
  
            for (int i = 0; i < t; ++i)
            {             
                    Console.Write("myArr["+i+"]: ");
                    Console.WriteLine(myArr[i][0]);   
            }

            StreamWriter print = new StreamWriter("C:\\Users\\Student\\Downloads\\lab3NET\\lab3text.txt", false); // перезапись в файл
            for (int i = 0; i < t; i++)
            {
                print.WriteLine(myArr[i][0] + " "); // запись в файл массива
            }
            print.Close();

            ///////////////////////////////////////
            /// 2 задание
            Console.WriteLine();

            int cnt = 0, count=0;
            int[] symbcount = new int[33];
            StreamReader sr = new StreamReader("C:\\Users\\Student\\Downloads\\lab3NET\\lab3text.txt");
            while (sr.Peek() != -1) {
                string str = sr.ReadLine();
                for(int i = 0; i < str.Length; i++)
                {
                    if (str[i] == 's')
                        cnt++;
                }     
                symbcount[count] = cnt;
                cnt = 0;
                Console.WriteLine("Кол-во символов 's' в "+count+" строке: "+ symbcount[count]);
                count++;
            }   
            Console.ReadLine();
        }
    }
}
