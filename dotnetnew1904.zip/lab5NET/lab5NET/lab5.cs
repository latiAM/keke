﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab5NET
{
    class lab5
    {
            class RadPlanet
            {
                private int[] raduis = new int[] { 2400, 6000, 6400, 3400, 71000, 60000, 26000, 25000 };

                public int this[int index]
                {
                    set { raduis[index] = value; }
                    get { return raduis[index]; }
                }
            }
            class NamePlanet
            {
                public string[] name = new string[] { "Меркурий", "Венера", "Земля", "Марс", "Юпитер", "Сатурн", "Уран", "Нептун" };
                public string this[int index]
                {
                    get
                    {
                        return name[index];
                    }
                    set
                    {
                        name[index] = value;
                    }
                }
            }
            static void Main(string[] args)
            {
                NamePlanet planet_name = new NamePlanet();
                RadPlanet planet_raduis = new RadPlanet();
                for (int i = 0; i < 8; i++)
                {
                    if (planet_raduis[i] > 6400)
                    {
                        Console.WriteLine(planet_name[i]);
                    }
                }
                Console.ReadKey();
            }
        
    }
}
