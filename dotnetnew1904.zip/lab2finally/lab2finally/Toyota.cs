﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2finally
{
    class Toyota : Car
    {
        private string name;
        public int speedy = 0;
        
        public Toyota()
        {
            name = "Toyota";
        }

        public override void SpeedUp()
        {
            if (speedy < 301)
                base.SpeedUp();
            else Console.WriteLine("Достигнута максимальная скорость!");
        }
    }
}
