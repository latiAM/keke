﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2finally
{
    class Radio
    {
        private bool flag;
        
        public Radio()
        {
            flag = false;
        }
        public void On()
        {
            if (!flag)
            {
                Console.WriteLine("\nРадио включено!");
                flag = true;
            }

            else Console.WriteLine("\nРадио уже включено!");
        }
        public void Off()
        {
            if (flag)
            {
                Console.WriteLine("\nРадио выключено!");
                flag = false;
            }
            else Console.WriteLine("\nРадио уже выключено!");
        }
    }
}
