﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2finally
{
    
    class Car : Radio
    {
        private int speed;
        private bool On;
        private bool Off;

        public Car()
        {
            On = false;
            Off = false;
            speed = 0;
        }
        public void Start()
        {
            if (!On)
            {
                Console.WriteLine("\nМашина завелась!");
                On = true;
                Off = false;
            }
            else Console.WriteLine("\nМашина уже была заведена!");
        }

        public void Stop()
        {
            if (Off == false)
            {
                
                if (speed < 1)
                {
                    Console.WriteLine("\nМашина остановилась!");
                    Off = false;
                    On = false;
                }
            }
            else if (Off == true) { Console.WriteLine("\nМашина уже была остановлена!"); }
            else Console.WriteLine("\nСнизьти скорость до 0 км/ч! (Скорость:  " + speed + " км/ч)"); 
        }

        public virtual void SpeedUp()
        {
            if (On)
            {
                speed += 75;
                Console.WriteLine("\nМашина ускорилась! Скорость:  " + speed + " км/ч");
                if(speed>=300) Console.WriteLine("\nОпасная скорость! Куда летишь, снижай скорость!");
               
            }
            else Console.WriteLine("Сначала нужно завести машину!");
        }

        public void SpeedDown()
        {
            if (!Off)
            {
                if (speed > 0)
                {
                    speed -= 75;
                    Console.WriteLine("\nМашина замедлилась! Скорость:  " + speed + " км/ч");
                }
                else
                    Console.WriteLine("\nМашина не может ехать медленнее!");
            }
            else Console.WriteLine("Сначала нужно завести машину!");
        }
    }
}
