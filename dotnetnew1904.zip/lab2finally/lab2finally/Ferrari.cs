﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2finally
{
    class Ferrari : Car
    {
        private string name;
        public Ferrari()
        {
            name = "Ferrari";
        }
    }
}
