﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab4_net
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        /*private void button1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.MdiParent = this;
            button1.Visible = false;
            button2.Visible = false;
            form2.LayoutMdi(MdiLayout.Cascade);
            form2.Show();
        }*/
        Form2 form2; //добавляем поле класса дочерней формы
        private void Form1_Load(object sender, EventArgs e)
        {
            notifyIcon1.BalloonTipTitle = "Some title";
            notifyIcon1.BalloonTipText = "Some Notification";
            notifyIcon1.Text = "lab4_net";
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.Show();
            notifyIcon1.Visible = false;
            WindowState = FormWindowState.Normal;
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Minimized)
            {
                this.Hide();
                notifyIcon1.Visible = true;
                notifyIcon1.ShowBalloonTip(1000);
            }
            else if (FormWindowState.Normal == this.WindowState)
            { notifyIcon1.Visible = false; }
        }

        private void закрытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void развернутьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Show();
            notifyIcon1.Visible = false;
            WindowState = FormWindowState.Normal;
        }

        private void form2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void открытьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
            if (form2 != null) //если ссылка не пустая
            {
                form2.Close(); //закрываем
                form2 = new Form2();
                form2.cnt = 0;
                form2.MdiParent = this;
                form2.LayoutMdi(MdiLayout.Cascade);
                form2.Show();
            }
            else
            {
                form2 = new Form2();
                form2.cnt = 0;
                form2.MdiParent = this;
                form2.LayoutMdi(MdiLayout.Cascade);
                form2.Show();
            }
        }

        private void закрытьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
            if (form2 != null) //если ссылка не пустая
            {
                form2.Close(); //закрываем
                form2 = new Form2();
                form2.cnt = 1;
                form2.MdiParent = this;
                form2.LayoutMdi(MdiLayout.Cascade);
                form2.Show();
            }
            else
            {
                form2 = new Form2();
                form2.cnt = 1;
                form2.MdiParent = this;
                form2.LayoutMdi(MdiLayout.Cascade);
                form2.Show();
            }
        }

        private void закрытьToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            if (form2 != null) //если ссылка не пустая
            {
                form2.Close(); //закрываем
            }
        }

        private void свернутьВТрейToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Visible = false; /* скроем форму */
            notifyIcon1.Visible = true; /* покажем икону в трее */
        }
    }
}
