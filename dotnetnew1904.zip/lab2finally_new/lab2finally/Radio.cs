﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2finally
{
    class Radio
    {
        private bool kek;
        
        public Radio()
        {
            kek = false;
        }
        public void On()
        {
            if (!kek)
            {
                Console.WriteLine("\nРадио включено! На волне: Ретро FM 88,3");
                kek = true;
            }

            else Console.WriteLine("\nРадио уже включено!");
        }
        public void Off()
        {
            if (kek)
            {
                Console.WriteLine("\nРадио выключено!");
                kek = false;
            }
            else Console.WriteLine("\nРадио уже выключено!");
        }
    }
}
