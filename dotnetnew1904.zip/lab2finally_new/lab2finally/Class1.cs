﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2finally
{
    class Class1
    {
        static void Main(string[] args)
        {

            ConsoleKeyInfo button1;
            do
            {
                Console.WriteLine("Выбор машины: \n " + "Z - Toyota X - Bugatti  C - Ferrari \n");
                
                button1 = Console.ReadKey();
                if (button1.Key == ConsoleKey.Z)
                {
                    Toyota toyota = new Toyota();
                    Console.WriteLine("\n\nToyota:\n" +"1 - Завести машину\n2 - Остановить машину\n" +"3 - Ускорить машину\n4 - Замедлить машину\n" +"5 - Включить радио\n" + "6 - Выключить радио\n0 - Выход\n");
                    do
                    {
                        button1 = Console.ReadKey();
                        switch (button1.Key)
                        {
                            case ConsoleKey.D1:
                                toyota.Start();
                                break;
                            case ConsoleKey.D2:
                                toyota.Stop();
                                break;
                            case ConsoleKey.D3:
                                if (toyota.speed != 300) { toyota.SpeedUp(); }
                                else Console.WriteLine("\nДостигнута максимальная скорость для этой машины!");        
                                break;
                            case ConsoleKey.D4:
                                toyota.SpeedDown();
                                break;
                            case ConsoleKey.D5:
                                toyota.On();
                                break;
                            case ConsoleKey.D6:
                                toyota.Off();
                                break;
                        }
                    } while (button1.Key != ConsoleKey.D0);
                    Console.WriteLine("\n");
                }
                
                else
                    if (button1.Key == ConsoleKey.C)
                {
                    Ferrari ferrari = new Ferrari();
                    Console.WriteLine("\nFerrari: \n"+"1 - Завести машину\n2 - Остановить машину\n" + "3 - Ускорить машину\n4 - Замедлить машину\n" + "5 - Включить радио\n" + "6 - Выключить радио\n0 - Выход\n");
                    do
                    {
                        button1 = Console.ReadKey();
                        switch (button1.Key)
                        {
                            case ConsoleKey.D1:
                                ferrari.Start();
                                break;
                            case ConsoleKey.D2:
                                ferrari.Stop();
                                break;
                            case ConsoleKey.D3:
                                ferrari.SpeedUp();
                                break;
                            case ConsoleKey.D4:
                                ferrari.SpeedDown();
                                break;
                            case ConsoleKey.D5:
                                ferrari.On();
                                break;
                            case ConsoleKey.D6:
                                ferrari.Off();
                                break;
                        }
                    } while (button1.Key != ConsoleKey.D0);
                    Console.WriteLine("\n");
                }
                else if (button1.Key == ConsoleKey.X)
                {
                    Bugatti bugatti = new Bugatti();
                    Console.WriteLine("\n\nBugatti:\n" + "1 - Завести машину\n2 - Остановить машину\n" + "3 - Ускорить машину\n4 - Замедлить машину\n" + "5 - Включить радио\n" + "6 - Выключить радио\n0 - Выход\n");
                    do
                    {
                        button1 = Console.ReadKey();
                        switch (button1.Key)
                        {
                            case ConsoleKey.D1:
                                bugatti.Start();
                                break;
                            case ConsoleKey.D2:
                                bugatti.Stop();
                                break;
                            case ConsoleKey.D3:
                                bugatti.SpeedUp();
                                break;
                            case ConsoleKey.D4:
                                bugatti.SpeedDown();
                                break;
                            case ConsoleKey.D5:
                                bugatti.On();
                                break;
                            case ConsoleKey.D6:
                                bugatti.Off();
                                break;
                        }
                    } while (button1.Key != ConsoleKey.D0);
                    Console.WriteLine("\n");
                }

            } while (button1.Key != ConsoleKey.Escape);


            Console.ReadKey();
        }
    }
}
