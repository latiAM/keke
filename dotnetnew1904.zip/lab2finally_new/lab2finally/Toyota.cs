﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2finally
{
    class Toyota : Car
    {
        private string name;
        private int speed;

        public Toyota()
        {
            name = "Toyota";
        }
    
        public int Speed { get => speed; set => speed = value; }

        public override void SpeedUp()
        {
            if (speed< 301)
                base.SpeedUp();
            else Console.WriteLine("Достигнута максимальная скорость!");
        }
    }
}
