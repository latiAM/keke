﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab5NET
{
    class lab5
    {
        
        static void Main(string[] args)
            {
                NamePlanet planet_name = new NamePlanet();
                RadPlanet planet_raduis = new RadPlanet();
                for (int i = 0; i < 8; i++)
                {
                    if (planet_raduis[i] > 6400)
                    {
                        Console.WriteLine(planet_name[i]);
                    }
                }

                Plus pt1 = new Plus(300);
                Plus pt2 = new Plus(240);
                // operator-
                Plus pt3 = pt1 - pt2;
                Plus pt4 = pt2 - pt3;
                 Plus pt5 = pt3 - pt4;

            Console.WriteLine();
            Console.WriteLine(pt3.ToString());
                Console.WriteLine(pt4.ToString());
            Console.WriteLine(pt5.ToString());
            Console.ReadKey();
            }
        
    }
}
