﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab5NET
{
    class Plus
    {
        private int a;
        public Plus(int arg1)
        {   a = arg1;}
        public static Plus operator -(Plus pl1, Plus pl2)
        {
            Plus newPlus = new Plus(pl1.a + pl2.a);
            return newPlus;
        }
        public override string ToString()
        {
            return "A = " + a;
        }
    }
}
