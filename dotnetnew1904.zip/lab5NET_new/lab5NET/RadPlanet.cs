﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab5NET
{
    class RadPlanet
    {
        private int[] raduis = new int[]
        { 2400, 6000, 6400, 3400, 71000, 60000, 26000, 25000 };

        public int this[int index]
        {
            set { raduis[index] = value; }
            get { return raduis[index]; }
        }
    }
}
