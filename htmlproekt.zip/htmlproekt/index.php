<?php
include_once("connect.php");
if(!mysqli_ping($connect))
    die("Ошибка соединения с базой данных");
$command = "select * from team_east";
$query = mysqli_query($connect, $command);
if($query)
{
    while($row = mysqli_fetch_array($query))
        {
            echo $row['team1'];
		echo $row['team2'];
		echo $row['team3'];
		echo $row['team4'];
		echo $row['team5'];
        }
}

else echo "Ошибка выполнения запроса";
mysqli_close($connect);

?>