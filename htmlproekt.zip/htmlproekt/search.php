<?php 
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'basketball');
$link = mysqli_connect("localhost", "root", "", "basketball");
if (!mysqli_connect(DB_HOST, DB_USER, DB_PASS)) {
    exit('Cannot connect to server');
}
if (!mysqli_select_db($link, "basketball")) {
    exit('Cannot select database');
}

mysqli_query('SET NAMES utf8');

function search ($query) 
{ 
    $query = trim($query); 
    $query = mysqli_real_escape_string($query);
    $query = htmlspecialchars($query);

    if (!empty($query)) 
    { 
        if (strlen($query) < 3) {
            $text = '<p>Слишком короткий поисковый запрос.</p>';
        } else if (strlen($query) > 128) {
            $text = '<p>Слишком длинный поисковый запрос.</p>';
        } else { 
            $q = "SELECT * FROM `players`";

            $result = mysqli_query($q);

            if (mysqli_affected_rows() > 0) { 
                $row = mysqli_fetch_assoc($result); 
                $num = mysqli_num_rows($result);

                $text = '<p>По запросу <b>'.$query.'</b> найдено совпадений: '.$num.'</p>';

                do {
                    // Делаем запрос, получающий ссылки на статьи
                    $q1 = "SELECT * FROM east teams";
                    $result1 = mysqli_query($q1);

                    if (mysqli_affected_rows() > 0) {
                        $row1 = mysqli_fetch_assoc($result1);
                    }

                    $text .= 'text';

                } while ($row = mysqli_fetch_assoc($result)); 
            } else {
                $text = '<p>По вашему запросу ничего не найдено.</p>';
            }
        } 
    } else {
        $text = '<p>Задан пустой поисковый запрос.</p>';
    }

    return $text; 
} 
?>