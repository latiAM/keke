<?php
# here database details      
$link = mysqli_connect('hostname', 'root', '');
mysqli_select_db($link,'basketball');

$sql = "SELECT * FROM players";
$result = mysqli_query($link, $sql);

$i=0;
        if (mysqli_num_rows($result) > 0) {
            // output data of each row
            
            while ($row = mysqli_fetch_assoc($result)) {
                echo "Player: " . $row["player"+$i];
                $i++;
            }
        } else {
            echo "0 results";
        }


        mysqli_close($link);
?>