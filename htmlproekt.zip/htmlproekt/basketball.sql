-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 28 2021 г., 03:39
-- Версия сервера: 8.0.24
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `basketball`
--

-- --------------------------------------------------------

--
-- Структура таблицы `players`
--

CREATE TABLE `players` (
  `player1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `player2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `player3` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `player4` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `player5` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `player6` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `player7` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `player8` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `player9` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `player10` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `players`
--

INSERT INTO `players` (`player1`, `player2`, `player3`, `player4`, `player5`, `player6`, `player7`, `player8`, `player9`, `player10`) VALUES
('Stephen\r\nCurry', 'Jayson\r\nTatum', 'Kevin\r\nDurant', 'Trae\r\nYoung', 'Donovan\r\nMitchell', 'Giannis\r\nAntetokounmpo', 'Zach\r\nLaVine', 'Karl-Anthony\r\nTowns', 'DeMar\r\nDeRozan', 'Nikola\r\nJokic');

-- --------------------------------------------------------

--
-- Структура таблицы `team_east`
--

CREATE TABLE `team_east` (
  `team1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `team2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `team3` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `team4` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `team5` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `team6` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `team7` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `team8` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `team9` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `team10` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `team11` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `team12` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `team13` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `team14` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `team15` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `team_east`
--

INSERT INTO `team_east` (`team1`, `team2`, `team3`, `team4`, `team5`, `team6`, `team7`, `team8`, `team9`, `team10`, `team11`, `team12`, `team13`, `team14`, `team15`, `id`) VALUES
('Бруклин Нетс', 'Чикаго Буллс', 'Милуоки Бакс', 'Майами Хит', 'Кливленд Кавальерс', 'Филадельфия Севенти Сиксерс', 'Вашингтон Уизардс', 'Шарлотт Хорнетс', 'Бостон Селтикс', 'Атланта Хоукс', 'Торонто Рэпторс', 'Нью-Йорк Никс', 'Индиана Пэйсерс', 'Орландо Мэджик', 'Детройт Пистонс', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `team_west`
--

CREATE TABLE `team_west` (
  `team1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `team2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `team3` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `team4` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `team5` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `team6` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `team7` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `team8` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `team9` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `team10` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `team11` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `team12` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `team13` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `team14` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `team15` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `team_west`
--

INSERT INTO `team_west` (`team1`, `team2`, `team3`, `team4`, `team5`, `team6`, `team7`, `team8`, `team9`, `team10`, `team11`, `team12`, `team13`, `team14`, `team15`) VALUES
('Голден Стэйт Уорриорз', 'Финикс Санз', 'Юта Джаз', 'Мемфис Гриззлис', 'ЛА Клипперс', 'Денвер Наггетс', 'Лос-Анджелес Лейкерс', 'Даллас Мэверикс', 'Миннесота Тимбервулвс', 'Сан-Антонио Сперс', 'Портленд Трэйл Блэйзерс', 'Сакраменто Кингз', 'Оклахома-Сити Тандер', 'Новый Орлеан Пеликанс', 'Хьюстон Рокетс');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `players`
--
ALTER TABLE `players`
  ADD UNIQUE KEY `1` (`player1`(1));

--
-- Индексы таблицы `team_east`
--
ALTER TABLE `team_east`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
