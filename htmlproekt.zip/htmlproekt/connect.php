<?php
$host = "localhost";
$user = "root";
$passw = "";
$db = "basketball";

$connect = new mysqli($host, $user, $passw, $db)
     OR die("Ошибка подключения к базе данных".mysqli_connect_error());
?>