﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab3YazykProgr
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Dictionary<string, string> parts = new Dictionary<string, string>();

        private void Form1_Load(object sender, EventArgs e)
        {
                   

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            parts = new Dictionary<string, string>();

                int i = 0;
                string subText = "";
                foreach (char s in textBox1.Text + " ")
                {
                    if (Lexema.IsOperator(subText) &&
                        (s == ' ' || s == '<' || s == '>' || s == ';'))
                    {
                        i++;
                        parts.Add(i.ToString() + " " + subText, "Operator");
                        subText = "";
                    }
                    else if (Lexema.IsArithmOperator(subText) &&
                        (s == ' ' || s == '(' || Char.IsDigit(s) || Char.IsLetter(s)))
                    {
                        i++;
                        parts.Add(i.ToString() + " " + subText, "Oper");
                        subText = "";
                    }
                    else if (Lexema.IsNumber(subText) &&
                        (s == ' ' || s == ';' || s == ')'))
                    {
                        i++;
                        parts.Add(i.ToString() + " " + subText, "Number");
                        subText = "";
                    }
                    else if (Lexema.CanBeVariable(subText) &&
                        !Lexema.IsOperator(subText) &&
                        (s == ' ' || s == '<' || s == '>' || s == ';' ||
                        s == '+' || s == '-' || s == '*' || s == '/'))
                    {
                        i++;
                        parts.Add(i.ToString() + " " + subText, "Variable");
                        subText = "";
                    }
                    else if (Lexema.IsSemicolon(subText))
                    {
                        i++;
                        parts.Add(i.ToString() + " " + subText, "Semicolon");
                        subText = "";
                    }
                    else if (Lexema.IsIO(subText))
                    {
                        i++;
                        parts.Add(i.ToString() + " " + subText, "IO");
                        subText = "";
                    }
                    else if (Lexema.IsBracket(subText))
                    {
                        i++;
                        parts.Add(i.ToString() + " " + subText, "Bracket");
                        subText = "";
                    }
                    else if (Lexema.IsIf(subText) &&
                        (s == ' ' || s == '('))
                    {
                        i++;
                        parts.Add(i.ToString() + " " + subText, "If");
                        subText = "";
                    }
                    else if (subText == Environment.NewLine || subText == " ")
                    {
                        subText = "";
                    }

                    subText += s;
                }




                textBox2.Clear();
                foreach (KeyValuePair<string, string> pair in parts)
                {
                    textBox2.Text += Environment.NewLine +
                        pair.Key.PadRight(20) + " " + pair.Value;
                }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
        
    }
}
