var bg = new Image();
bg.src = "images/bg2.jpg";

var cat = [new Image()];
var rat = [new Image()];
for(var i=0; i<7; i++)
{
    cat[i].src = "images/cat"+(i+1)+".png";
    cat.push(new Image());
    rat[i].src = "images/rat"+(i+1)+".png";
    rat.push(new Image());
}

var cvs = document.getElementById("canvas");
var ctx = cvs.getContext("2d");

cvs.width  = window.innerWidth;
cvs.height = window.innerHeight;

var i=0, j=0, Xcat=450; Xmes=0; Xm1=0, Xm2 =0; Xm3=0;
var posX = 0;
//<input onmousemove="this.value = event.clientX+':'+event.clientY"></input>
  
function drawCat() {
    setTimeout(function() {
        //рисуем фон:
        ctx.drawImage(bg, posX, 0, cvs.width, cvs.height);
        ctx.drawImage(bg, cvs.width+posX, 0, cvs.width, cvs.height);
        posX -= 5;
        if(posX <= -cvs.width) posX = 0;
        //if(event.which == 1) Xcat = event.clientX;
        //рисуем кота:
        ctx.drawImage(cat[i], Xcat, 280);
        i++;
        if(i == 7) i = 0;
        ctx.drawImage(rat[j], Xmes, 420);
        ctx.drawImage(rat[j], Xm1, 560);
        ctx.drawImage(rat[j], Xm2, 700);
        ctx.drawImage(rat[j], Xm3, 220);
        j++; Xmes=Xmes+50; Xm1=Xm1+22; Xm2=Xm2+30; Xm3=Xm3+70;
        if(j == 2) j = 0;
        if(Xmes == 1700) Xmes=0;
        if(Xm1 == 1700) Xm1=0;
        if(Xm2 == 1710) Xm2=0;
        if(Xm3 == 1750) Xm3=0;
        
        requestAnimationFrame(drawCat); //устанавливаем цикл на функцию
    }, 80);                           
}

drawCat();