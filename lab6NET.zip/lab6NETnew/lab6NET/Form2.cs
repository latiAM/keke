﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab6NET
{
    public partial class Form2 : Form
    {
        
        private string artist = "";
        private int step = 0;
        private int amount = 0;
        public Form2(string art_name)
        {
            InitializeComponent();
            artist = art_name;
            this.Text = artist;
            groupBox1.Text = artist;
            string bio3 = 
                "Русский художник-живописец и архитектор, мастер исторической и фольклорной живописи. Васнецов является основоположником «неорусского стиля», преобразованного из исторического жанра и романтических тенденций, связанных с фольклором и символизмом. Творчество художника сыграло важную роль в развитии российского изобразительного искусства от эпохи передвижничества к стилю модерн. Действительный статский советник.Младший брат -художник Аполлинарий Васнецов." +
                "\nРодился: 15 мая 1848 г., Лопьял" +
                "\nУмер: 23 июля 1926 г. (78 лет), Москва, РСФСР, СССР";
            string bio2 = 
                "Русский художник-маринист армянского происхождения, коллекционер, меценат. Живописец Главного Морского штаба, действительный тайный советник, академик и почётный член Императорской Академии художеств, почётный член Академий художеств в Амстердаме, Риме, Париже, Флоренции и Штутгарте." +
                "\nРодился: 29 июля 1817 г., Феодосия, Таврическая губерния(Крым), Российская империя" +
                "\nУмер: 19 апреля 1900 г. (82 года), Феодосия, Таврическая губерния, Российская империя";
            string bio1 = 
                "Испанский живописец, график, скульптор, режиссёр и писатель. Один из самых известных представителей сюрреализма. Работал над фильмами: «Андалузский пёс», «Золотой век», «Заворожённый»." +
                "\nРодился: 11 мая 1904 г., Фигерас, Каталония, Испания" +
                "\nУмер: 23 января 1989 г. (84 года), Фигерас, Каталония, Испания" +
                "\nЦитата: Только идиоты полагают, что я следую советам, которые даю другим. Я ведь совершенно не похож на других.";
            if (artist == "Сальвадор Дали") label1.Text = bio1;
            else if(artist == "Иван Айвазовски") label1.Text = bio2;
            else label1.Text = bio3;
            string img_path = @".\images\" + artist + "\\1.jpg";
            pictureBox1.Image = Image.FromFile(img_path);
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            string img_path = @".\images\"+ artist +"\\1.jpg";
            
            pictureBox1.Image = Image.FromFile(img_path);
            
        }
       

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            step++;
            if (step == 2)
                button1.Enabled = false;
            else button1.Enabled = true;
            if (step == amount - 1)
                button2.Enabled = false;
            else button2.Enabled = true;
            string path = @".\images\" + artist;
            DirectoryInfo dir = new DirectoryInfo(path);
            FileInfo[] imageFiles = dir.GetFiles();
            pictureBox1.Image = Image.FromFile(imageFiles[step].FullName);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            step--;
            if (step == 0)
                button2.Enabled = false;
            else button2.Enabled = true;
            if (step == amount - 1)
                button1.Enabled = false;
            else button1.Enabled = true;
            string path = @".\images\" + artist;
            DirectoryInfo dir = new DirectoryInfo(path);
            FileInfo[] imageFiles = dir.GetFiles();
            pictureBox1.Image = Image.FromFile(imageFiles[step].FullName);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 newForm1 = new Form1();

            this.Close();
            newForm1.Show();
            
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
            
        }
    }
}
